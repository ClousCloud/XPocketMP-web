<?php

require __DIR__ . '/vendor/autoload.php';

use App\Controllers\AuthController;
use App\Controllers\BuildingController;
use App\Controllers\ContactController;
use App\Controllers\AdminController;
use App\Controllers\HomeController;
use Dotenv\Dotenv;

session_start();

$requestUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

switch ($requestUri) {
    case '/':
        (new HomeController())->index();
        break;
    case '/login':
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            (new AuthController())->showLoginForm();
        } else {
            (new AuthController())->login();
        }
        break;
    case '/register':
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            (new AuthController())->showRegisterForm();
        } else {
            (new AuthController())->register();
        }
        break;
    case '/logout':
        (new AuthController())->logout();
        break;
    case '/contact':
        (new ContactController())->submitContactForm();
        break;
    case '/home':
        include __DIR__ . '/views/home.php';
        break;
    case '/admin':
        (new AdminController())->index();
        break;
    case '/building':
        (new BuildingController())->index();
        break;
    default:
        include __DIR__ . ('/src/views/404.php');
        break;
}
$dotenv = Dotenv::createImmutable(__DIR__ . '/');
$dotenv->load();

var_dump($_ENV);