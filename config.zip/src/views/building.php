<?php include 'layout.php'; ?>

<div class="container mt-5">
    <h1 class="mb-4">Building</h1>

    <h2>Pre-requisites</h2>
    <ul>
        <li>A bash shell (git bash is sufficient for Windows)</li>
        <li><a href="https://git-scm.com" target="_blank">git</a> available in your shell</li>
        <li>PHP 8.2 or newer available in your shell</li>
        <li><a href="https://getcomposer.org" target="_blank">composer</a> available in your shell</li>
    </ul>

    <h2>Custom PHP binaries</h2>
    <p>Because XPocketMP requires several non-standard PHP extensions and configuration, PMMP provides scripts to build custom binaries for running XPocketMP, as well as prebuilt binaries.</p>
    <ul>
        <li><a href="https://github.com/pmmp/PHP-Binaries/releases" target="_blank">Prebuilt binaries</a></li>
        <li><a href="https://github.com/pmmp/php-build-scripts" target="_blank">Compile scripts</a> are provided as a submodule in the path <code>build/php</code></li>
    </ul>
    <p>If you use a custom binary, you'll need to replace <code>composer</code> usages in this guide with <code>path/to/your/php path/to/your/composer.phar</code>.</p>

    <h2>Setting up environment</h2>
    <ol>
        <li><code>git clone https://github.com/xpocketmc/XPocketMP.git</code></li>
        <li><code>composer install</code></li>
    </ol>

    <h2>Checking out a different branch to build</h2>
    <ol>
        <li><code>git checkout &lt;branch to checkout&gt;</code></li>
        <li>Re-run <code>composer install</code> to synchronize dependencies.</li>
    </ol>

    <h2>Optimizing for release builds</h2>
    <p>Add the flags <code>--no-dev --classmap-authoritative</code> to your <code>composer install</code> command. This will reduce build size and improve autoloading speed.</p>

    <h2>Building <code>XPocketMP.phar</code></h2>
    <p>Run <code>composer make-server</code> using your preferred PHP binary. It'll drop a <code>XPocketMP.phar</code> into the current working directory.</p>
    <p>You can also use the <code>--out</code> option to change the output filename.</p>

    <h2>Running XPocketMP from source code</h2>
    <p>Run <code>src/XPocketMP.php</code> using your preferred PHP binary.</p>
</div>