<?php include('layout.php'); ?>
<div class="container mt-5">
    <h1>Login</h1>
    <form action="/login" method="POST">
      <div class="mb-3">
        <label class="form-label" for="email">Email:</label>
        <input class="form-control" type="email" name="email" id="email" required>
      </div>
      <div class="mb-3">
        <label for="password">Password:</label>
        <input class="form-control" type="password" name="password" id="password" required>
      </div>
        <button class="btn btn-primary" type="submit">Login</button>
    </form>
    <div class="mb-3">
    <p class="p">Don't have an account? <a href="/register">Register here</a></p>
    </div>
    </form>
    <style>
      .p {
        text-align: center;
        text-decoration: none;
      }
      
      a {
        text-decoration: none;
      }
    </style>