<?php include 'layout.php'; ?>

<div class="container mt-5">
    <div class="text-center">
        <img src="https://raw.githubusercontent.com/xpocketmc/XPocketMP-server/stable/.github/readme/20240621_222553.png" alt="The XPocketMP logo" class="img-fluid" title="XPocketMP" loading="eager" />
        <h1 class="mt-3">XPocketMP</h1>
        <p class="lead"><strong>A highly customisable, open source server software for Minecraft: Bedrock Edition written in PHP</strong></p>
    </div>

    <div class="text-center mt-4">
        <a href="https://github.com/xpocketmc/XPocketMP-server/actions/workflows/main.yml" class="btn btn-outline-secondary">
            <img src="https://github.com/xpocketmc/XPocketMP-server/workflows/CI/badge.svg" alt="CI" />
        </a>
        <a href="https://github.com/xpocketmc/XPocketMP-server/releases/latest" class="btn btn-outline-secondary">
            <img alt="GitHub release (latest SemVer)" src="https://img.shields.io/github/v/release/xpocketmc/XPocketMP-server">
        </a>
        <a href="https://discord.gg/bmSAZBG" class="btn btn-outline-secondary">
            <img src="https://img.shields.io/discord/1253659229189963796?label=discord&color=7289DA&logo=discord" alt="Discord" />
        </a>
        <a href="https://github.com/xpocketmc/XPocketMP-server/release" class="btn btn-outline-secondary">
            <img alt="GitHub all releases" src="https://img.shields.io/github/downloads/xpocketmc/XPocketMP-server/total?label=downloads%40total">
        </a>
        <a href="https://github.com/xpocketmc/XPocketMP-server/releases/latest" class="btn btn-outline-secondary">
            <img alt="GitHub release (latest by SemVer)" src="https://img.shields.io/github/downloads/xpocketmc/XPocketMP-server/latest/total?sort=semver">
        </a>
    </div>

    <div class="mt-5">
        <h2>What is this?</h2>
        <p>XPocketMP is a highly customisable server software for Minecraft: Bedrock Edition, built from scratch in PHP, with over 1 years of history.</p>
        <p>If you're looking to create a Minecraft: Bedrock server with <strong>custom functionality</strong>, look no further.</p>
        <ul>
            <li>🧩 <strong>Powerful plugin API</strong> - extend and customise gameplay as you see fit</li>
            <li>🗺️ <strong>Rich ecosystem</strong> and <strong>large developer community</strong> - find plugins easily and learn to develop your own</li>
            <li>🌐 <strong>Multi-world support</strong> - offer a more varied game experience to players without transferring them to other server nodes</li>
            <li>🏎️ <strong>Performance</strong> - get 100+ players onto one server (depending on hardware and plugins)</li>
            <li>⤴️ <strong>Continuously updated</strong> - new Minecraft versions are usually supported within days</li>
        </ul>
    </div>

    <div class="mt-5">
        <h2>⚠️ XPocketMP is NOT a vanilla Minecraft server software.</h2>
        <p><strong>It is poorly suited to hosting vanilla survival servers.</strong> It doesn't have many features from the vanilla game, such as vanilla world generation, redstone, mob AI, and various other things.</p>
        <p>If you just want to play <strong>vanilla survival multiplayer</strong>, consider using the <a href="https://minecraft.net/download/server/bedrock">official Minecraft: Bedrock server software</a> instead of XPocketMP.</p>
        <p>If that's not an option for you, you may be able to add some of XPocketMP's missing features using plugins from <a href="https://poggit.pmmp.io/plugins">Poggit</a>, or write plugins to implement them yourself.</p>
    </div>

    <div class="mt-5">
        <h2>Getting Started</h2>
        <ul>
            <li><a href="http://pmmp.readthedocs.org/">Documentation</a></li>
            <li><a href="https://pmmp.readthedocs.io/en/rtfd/installation.html">Installation instructions</a></li>
            <li><a href="https://github.com/xpocketmc/XPocketMP-server/pkgs/container/xpocketmp-server">Docker image</a></li>
            <li><a href="https://poggit.pmmp.io/plugins">Plugin repository</a></li>
        </ul>
    </div>

    <div class="mt-5">
        <h2>Community & Support</h2>
        <p>Join our <a href="https://discord.gg/bmSAZBG">Discord</a> server to chat with other users and developers.</p>
        <p>Join the <a href="https://whatsapp.com/channel/0029Vadnurk6xCSYTSmEXm1f">WhatsApp</a> channel to notify additional updates and others.</p>
    </div>

    <div class="mt-5">
        <h2>Developing Plugins</h2>
        <p>If you want to write your own plugins, the following resources may be useful. Don't forget you can always ask our community if you need help.</p>
        <ul>
            <li><a href="https://devdoc.pmmp.io">Developer documentation</a> - General documentation for XPocketMP plugin developers</li>
            <li><a href="https://apidoc.pmmp.io">Latest release API documentation</a> - Doxygen API documentation generated for each release</li>
            <li><a href="https://apidoc-dev.pmmp.io">Latest bleeding-edge API documentation</a> - Doxygen API documentation generated weekly from <code>major-next</code> branch</li>
            <li><a href="https://github.com/pmmp/DevTools/">DevTools</a> - Development tools plugin for creating plugins</li>
            <li><a href="https://github.com/pmmp/ExamplePlugin/">ExamplePlugin</a> - Example plugin demonstrating some basic API features</li>
        </ul>
    </div>

    <div class="mt-5">
        <h2>Contributing to XPocketMP</h2>
        <p>XPocketMP accepts community contributions! The following resources will be useful if you want to contribute to XPocketMP.</p>
        <ul>
            <li><a href="building">Building and running XPocketMP from source</a></li>
            <li><a href="CONTRIBUTING.md">Contributing Guidelines</a></li>
        </ul>
    </div>

    <div class="mt-5">
        <h2>Donate</h2>
        <p>XPocketMP is free, but it requires a lot of time and effort from unpaid volunteers to develop. Donations enable us to keep delivering support for new versions and adding features your players love.</p>
        <p>You can support development using the following methods:</p>
        <ul>
            <li>Paypal: <code>gameplaytebakgambard@gmail.com</code></li>
        </ul>
        <p>Thanks for your support!</p>
    </div>

    <div class="mt-5">
        <h2>Licensing information</h2>
        <p>This project is licensed under LGPL-3.0. Please see the <a href="https://github.com/xpocketmc/XPocketMP-server/blob/stable/LICENSE">LICENSE</a> file for details.</p>
        <p>xpocketmc/XPocketMP are not affiliated with Mojang. All brands and trademarks belong to their respective owners. XPocketMP is not a Mojang-approved software, nor is it associated with Mojang.</p>
    </div>
</div>