<?php

namespace App\Controllers;

class BuildingController {
  
  public function index() {
    include __DIR__ . ('/../views/building.php');
  }
}