<?php

namespace App\Models;

use App\Config\Database;
use PDO;

class User
{
    private $id;
    private $name;
    private $email;
    private $password;
    private $is_admin;

    public function __construct($name = '', $email = '', $password = '', $is_admin = 0)
    {
        $this->name = $name;
        $this->email = $email;
        $this->password = $password;
        $this->is_admin = $is_admin;
    }

    public function save()
    {
        $db = (new Database())->getConnection();
        $stmt = $db->prepare("INSERT INTO users (name, email, password, is_admin) VALUES (:name, :email, :password, :is_admin)");
        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':email', $this->email);
        $hashedPassword = password_hash($this->password, PASSWORD_DEFAULT);
        $stmt->bindParam(':password', $hashedPassword);
        $stmt->bindParam(':is_admin', $this->is_admin);
        $stmt->execute();
    }

    public static function findByEmail($email)
    {
        $db = (new Database())->getConnection();
        $stmt = $db->prepare("SELECT * FROM users WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        return $stmt->fetchObject(__CLASS__);
    }

    public function getId()
    {
        return $this->id;
    }

    public function getName()
    {
        return $this->name;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    public function getEmail()
    {
        return $this->email;
    }

    public function setEmail($email)
    {
        $this->email = $email;
    }

    public function getPassword()
    {
        return $this->password;
    }

    public function setPassword($password)
    {
        $this->password = $password;
    }

    public function isAdmin()
    {
        return $this->is_admin;
    }

    public function setAdmin($is_admin)
    {
        $this->is_admin = $is_admin;
    }

    public static function register($name, $email, $password)
    {
        $user = new self($name, $email, $password);
        $user->save();
    }

    public static function login($email, $password)
    {
        $user = self::findByEmail($email);
        if ($user && password_verify($password, $user->password)) {
            return $user;
        }
        return false;
    }
}