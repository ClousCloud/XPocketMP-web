<?php include 'layout.php'; ?>
<div class="container mt-5">
<h1>Welcome to XPocketMP</h1>
<p>This is the home page.</p>
</div>