<?php

namespace App\Controllers;

use App\Models\Contact;

class ContactController
{
    public function showContactForm()
    {
        include __DIR__ . '/../views/contact.php';
    }

    public function submitContactForm()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $message = $_POST['message'];

            $contact = new Contact();
            $contact->setName($name);
            $contact->setEmail($email);
            $contact->setMessage($message);
            $contact->save();

            // Redirect atau tampilkan pesan sukses
            header('Location: /thank-you');
            exit();
        }
    }
}