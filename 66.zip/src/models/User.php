<?php

namespace App\Models;

use PDO;
use App\Config\Database;

class User
{
    public static function findByEmail($email)
    {
        $db = Database::getConnection();
        $stmt = $db->prepare('SELECT * FROM users WHERE email = ?');
        $stmt->execute([$email]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}