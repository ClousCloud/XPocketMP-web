<?php

namespace App\Models;

use App\Config\Database;
use PDO;

class Contact
{
    private $name;
    private $email;
    private $message;

    public function __construct($name = '', $email = '', $message = '')
    {
        $this->name = $name;
        $this->email = $email;
        $this->message = $message;
    }

    public function save()
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("INSERT INTO contacts (name, email, message) VALUES (:name, :email, :message)");
        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':message', $this->message);
        $stmt->execute();
    }

    // Getter dan Setter untuk properti
    public function getName()
    {
        return $this->name;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    public function getEmail()
    {
        return $this->email;
    }

    public function setEmail($email)
    {
        $this->email = $email;
    }

    public function getMessage()
    {
        return $this->message;
    }

    public function setMessage($message)
    {
        $this->message = $message;
    }
}