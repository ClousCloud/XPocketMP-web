<?php

namespace App\Middleware;

class AuthMiddleware
{
    public function handle($request, $next)
    {
        // Middleware logic here
        return $next($request);
    }
}