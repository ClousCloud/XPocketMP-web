<?php

namespace App\Config;

use PDO;

class Database
{
    private static $connection;

    public static function getConnection()
    {
        if (self::$connection === null) {
            $dsn = 'mysql:host=' . getenv('DB_HOST') . ';dbname=' . getenv('DB_DATABASE');
            self::$connection = new PDO($dsn, getenv('DB_USERNAME'), getenv('DB_PASSWORD'));
            self::$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }

        return self::$connection;
    }
}
