<?php

require __DIR__ . '/vendor/autoload.php';

use Dotenv\Dotenv;
use App\Controllers\ContactController;
use App\Controllers\AdminController;
use App\Middleware\UserAuth;

$dotenv = Dotenv::createImmutable(__DIR__ . '');
$dotenv->load();

$requestUri = $_SERVER['REQUEST_URI'];

if ($requestUri === '/' || $requestUri === '/home') {
    include __DIR__ . '/src/views/home.php';
} elseif ($requestUri === '/contact') {
    $controller = new ContactController();
    $controller->showContactForm();
} elseif ($requestUri === '/submit-contact' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller = new ContactController();
    $controller->submitContactForm();
} elseif ($requestUri === '/admin') {
    $controller = new AdminController();
    $controller->index();
} else {
    // Route not found, show 404 page
    include __DIR__ . '/src/views/404.php';
}